### REST API STEPS ###

# RUN COMMANDS
npm run install
npm run dev

# RUN ENDPOINT
http://www.localhost:80/api/
